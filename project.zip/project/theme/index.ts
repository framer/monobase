export const pill = {
	padding: "24px 50px 26px",
	userSelect: "none",
	borderRadius: 8,
	border: 0,
	outline: 0,
	lineHeight: 1,
	fontSize: 24
}
