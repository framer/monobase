import * as React from "react";

import Template from "components/Template";

export default function render() {
  return (
    <Template>
      <h3>404 File not found</h3>
    </Template>
  );
}
